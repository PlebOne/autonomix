"""Autonomix - A Linux package manager for GitHub releases."""

__version__ = "0.1.1"
